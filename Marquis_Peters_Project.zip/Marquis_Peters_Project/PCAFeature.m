function [ image_property ] = PCAFeature( image, V )



end

